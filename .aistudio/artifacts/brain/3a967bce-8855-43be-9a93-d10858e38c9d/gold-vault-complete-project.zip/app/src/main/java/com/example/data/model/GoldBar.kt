package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room database entity representing a gold bar in the inventory.
 * Stores weight, karat, cost, and status as required.
 */
@Entity(tableName = "gold_bars")
data class GoldBar(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String = "سبيكة BTC",
    val weight: Double, // Weight in grams: 0.5, 1.0, 10.0, 50.0, 31.1034768 (1 oz)
    val karat: Int = 24, // Karat (default 24k)
    val cost: Double? = null, // Purchase cost in EGP
    val status: String = "مغلفة وسليمة", // Status: "مغلفة وسليمة" (Sealed & intact), etc.
    val brand: String = "BTC",
    val notes: String = "",
    val serialNumber: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
