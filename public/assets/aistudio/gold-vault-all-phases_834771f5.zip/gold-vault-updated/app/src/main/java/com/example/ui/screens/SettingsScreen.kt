package com.example.ui.screens

import com.example.util.toDoubleOrNullLocalized
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.calculations.PortfolioCalculator
import com.example.security.LocalPinVerifier
import com.example.security.PinHasher
import com.example.security.PinResult
import com.example.security.toUserMessage
import kotlinx.coroutines.launch
import com.example.ui.PortfolioUiState
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.LossRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.util.Formatters
import java.util.Locale

@Composable
fun SettingsScreen(
    state: PortfolioUiState,
    onBack: () -> Unit,
    onSaveSettings: (baseline: Double, target: Double) -> Unit,
    onSaveCashBack: (amount: Double, notes: String) -> Unit,
    onResetBaseline: () -> Unit,
    onSavePriceAlerts: (enabled: Boolean, threshold: Double) -> Unit = { _, _ -> },
    onToggleAutoBullionCashBack: (Boolean) -> Unit = {},
    onUpdateSecuritySettings: (isAppLockEnabled: Boolean, requireAuthOnSale: Boolean, isBiometricEnabled: Boolean, securityPin: String) -> Unit = { _, _, _, _ -> },
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var baselineStr by remember(state.settings.initialBaselineEgp) {
        mutableStateOf(String.format(java.util.Locale.US, "%.2f", state.settings.initialBaselineEgp))
    }
    var targetStr by remember(state.settings.targetGoalEgp) {
        mutableStateOf(String.format(java.util.Locale.US, "%.2f", state.settings.targetGoalEgp))
    }
    var cashBackStr by remember(state.settings.confirmedCashBackEgp) {
        mutableStateOf(String.format(java.util.Locale.US, "%.2f", state.settings.confirmedCashBackEgp))
    }
    var cashBackNotes by remember(state.settings.cashBackSourceNotes) {
        mutableStateOf(state.settings.cashBackSourceNotes)
    }

    var priceAlertsEnabled by remember(state.settings.priceAlertsEnabled) {
        mutableStateOf(state.settings.priceAlertsEnabled)
    }
    var alertThresholdStr by remember(state.settings.priceAlertThresholdEgp) {
        mutableStateOf(state.settings.priceAlertThresholdEgp.toInt().toString())
    }
    var autoCashBackEnabled by remember(state.settings.autoAddBullionCashBack) {
        mutableStateOf(state.settings.autoAddBullionCashBack)
    }

    var appLockEnabled by remember(state.settings.isAppLockEnabled) {
        mutableStateOf(state.settings.isAppLockEnabled)
    }
    var requireAuthOnSale by remember(state.settings.requireAuthOnSale) {
        mutableStateOf(state.settings.requireAuthOnSale)
    }
    var biometricEnabled by remember(state.settings.isBiometricEnabled) {
        mutableStateOf(state.settings.isBiometricEnabled)
    }
    val hasPin = PinHasher.hasPin(state.settings.securityPin)
    val verifyPin = LocalPinVerifier.current
    val pinScope = rememberCoroutineScope()
    var pendingEnableLock by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }

    var showResetDialog by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إعدادات المحفظة والأهداف المالية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الرصيد الابتدائي هو الأساس المرجعي لحساب الأرباح والخسائر، ويظل ثابتاً ما لم تقم بتعديله هنا صراحة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Baseline and Target Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "الرصيد المرجعي والهدف المالي",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoldSecondary
                    )

                    OutlinedTextField(
                        value = baselineStr,
                        onValueChange = { baselineStr = it },
                        label = { Text("الرصيد الابتدائي للمحفظة (ج.م)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("baseline_input")
                    )

                    OutlinedTextField(
                        value = targetStr,
                        onValueChange = { targetStr = it },
                        label = { Text("الهدف المالي للمحفظة (ج.م)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("target_input")
                    )

                    Button(
                        onClick = {
                            val b = baselineStr.toDoubleOrNullLocalized()
                            val t = targetStr.toDoubleOrNullLocalized()
                            if (b == null || b <= 0.0 || t == null || t <= 0.0) {
                                errorMessage = "يرجى إدخال قيم مالية صحيحة أكبر من صفر"
                                return@Button
                            }
                            errorMessage = null
                            onSaveSettings(b, t)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_baseline_target_button")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ الرصيد والهدف")
                    }

                    OutlinedButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_baseline_button")
                    ) {
                        Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("استعادة الرصيد الابتدائي الافتراضي (1,000,462 ج.م)")
                    }
                }
            }
        }

        // Bullion Cash Back (28 EGP / gram) Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "كاش باك السبائك وإجمالي المبالغ المستردة",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoldSecondary
                    )
                    Text(
                        text = "معدل الكاش باك القياسي لسبائك الذهب في مصر (BTC وغيرها) هو 28 جنيه مصري / جرام تقريباً يُسترد من الصائغ عند استرجاع الغلاف الأمني السليم.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("إجمالي وزن سبائك المحفظة:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                Text(Formatters.formatWeight(state.totalBullionWeight), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("الكاش باك التقديري (28 ج.م/جم):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                Text(Formatters.formatCurrency(state.expectedBullionCashBack), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ProfitGreen)
                            }
                        }
                    }

                    // Auto Bullion Cash Back Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("إضافة الكاش باك القياسي (28 ج.م/جم) تلقائياً", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("تضمين 28 ج.م لكل جرام سبائك مباشرة في إجمالي تصفية المحفظة", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Switch(
                            checked = autoCashBackEnabled,
                            onCheckedChange = {
                                autoCashBackEnabled = it
                                onToggleAutoBullionCashBack(it)
                            }
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            val standardCb = state.expectedBullionCashBack
                            cashBackStr = String.format(Locale.US, "%.2f", standardCb)
                            cashBackNotes = "كاش باك معتمد للسبائك الأصلية (28 ج.م/جرام)"
                            onSaveCashBack(standardCb, cashBackNotes)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تثبيت الكاش باك القياسي (${Formatters.formatCurrency(state.expectedBullionCashBack)}) كقيمة مؤكدة")
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("أو تخصيص قيمة الكاش باك يدوياً:", style = MaterialTheme.typography.labelSmall, color = TextMuted)

                    OutlinedTextField(
                        value = cashBackStr,
                        onValueChange = { cashBackStr = it },
                        label = { Text("إجمالي Cash Back المؤكد (ج.م)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cashback_input")
                    )

                    OutlinedTextField(
                        value = cashBackNotes,
                        onValueChange = { cashBackNotes = it },
                        label = { Text("مصدر الكاش باك وملاحظات التوثيق") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cashback_notes_input")
                    )

                    Button(
                        onClick = {
                            val cb = cashBackStr.toDoubleOrNullLocalized() ?: 0.0
                            if (cb < 0.0) {
                                errorMessage = "لا يمكن أن يكون الكاش باك بالسالب"
                                return@Button
                            }
                            errorMessage = null
                            onSaveCashBack(cb, cashBackNotes)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_cashback_button")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ الكاش باك المؤكد")
                    }
                }
            }
        }

        // Price Movement Alerts Card (رابعاً: تنبيهات تحرك السعر)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "تنبيهات حركة أسعار الذهب",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = GoldSecondary
                    )
                    Text(
                        text = "إشعارك فورياً كلما تحرك سعر جرام الذهب صعوداً أو هبوطاً بمقدار محدد.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("تفعيل التنبيهات اللحظية", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("إرسال تنبيه في شريط التطبيق عند رصد تغير بالأسعار", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Switch(
                            checked = priceAlertsEnabled,
                            onCheckedChange = { priceAlertsEnabled = it }
                        )
                    }

                    if (priceAlertsEnabled) {
                        Text(
                            text = "مقدار تحرك السعر المشترط للتنبيه (جنيه/جرام):",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(10, 25, 50, 100).forEach { th ->
                                val isSelected = alertThresholdStr == th.toString()
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) GoldContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { alertThresholdStr = th.toString() }
                                        .border(1.dp, if (isSelected) GoldPrimary else Color.Transparent, RoundedCornerShape(8.dp))
                                ) {
                                    Text(
                                        text = "$th ج.م",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) GoldPrimary else TextSecondary,
                                        textAlign = TextAlign.Center,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = alertThresholdStr,
                            onValueChange = { alertThresholdStr = it },
                            label = { Text("قيمة مخصصة لهامش التنبيه (ج.م)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            trailingIcon = { Text("ج.م", color = GoldSecondary, modifier = Modifier.padding(end = 12.dp)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                val threshold = alertThresholdStr.toDoubleOrNullLocalized() ?: 25.0
                                if (threshold <= 0.0) {
                                    errorMessage = "يرجى تحديد هامش تنبيه أكبر من صفر"
                                    return@Button
                                }
                                errorMessage = null
                                onSavePriceAlerts(priceAlertsEnabled, threshold)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("حفظ إعدادات التنبيهات")
                        }
                    }
                }
            }
        }

        // Security & Vault Lock Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الأمان وقفل الخزانة (Vault Security)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = GoldSecondary
                        )
                    }

                    Text(
                        text = "تأمين بيانات المحفظة الحساسة وتأكيد عمليات البيع والتسييل عبر البصمة الحيوية أو رمز المرور (PIN).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    // 1. App Lock Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("قفل التطبيق (App Lock)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("طلب رمز المرور أو البصمة عند فتح التطبيق", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Switch(
                            checked = appLockEnabled,
                            onCheckedChange = {
                                if (it && !hasPin) {
                                    // The lock needs a real PIN: ask for one first, enable after it is saved.
                                    pendingEnableLock = true
                                    showChangePinDialog = true
                                } else {
                                    appLockEnabled = it
                                    onUpdateSecuritySettings(it, requireAuthOnSale, biometricEnabled, "")
                                }
                            },
                            modifier = Modifier.testTag("app_lock_switch")
                        )
                    }

                    // 2. Require Auth on Sale Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("تأكيد البيع برمز المرور أو البصمة", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("طلب تأكيد أمني إلزامي قبل اعتماد بيع أي قطعة ذهبية", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Switch(
                            checked = requireAuthOnSale,
                            onCheckedChange = {
                                requireAuthOnSale = it
                                onUpdateSecuritySettings(appLockEnabled, it, biometricEnabled, "")
                            },
                            modifier = Modifier.testTag("require_auth_on_sale_switch")
                        )
                    }

                    // 3. Biometric Enabled Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("السماح بالبصمة الحيوية (Biometrics)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("استخدام مستشعر بصمة الإصبع للفتح السريع", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Switch(
                            checked = biometricEnabled,
                            onCheckedChange = {
                                biometricEnabled = it
                                onUpdateSecuritySettings(appLockEnabled, requireAuthOnSale, it, "")
                            },
                            modifier = Modifier.testTag("biometric_enabled_switch")
                        )
                    }

                    // 4. Change PIN
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showChangePinDialog = true }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("تغيير رمز المرور (PIN)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text(if (hasPin) "تم تعيين رمز مرور (مخفي)" else "لم يُعيَّن رمز مرور بعد", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                            }
                            Text("تعديل", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = GoldPrimary)
                        }
                    }
                }
            }
        }

        if (errorMessage != null) {
            item {
                Text(text = errorMessage!!, color = LossRed, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("تأكيد استعادة الرصيد الافتراضي", fontWeight = FontWeight.Bold) },
            text = {
                Text("هل تريد استعادة الرصيد المرجعي الأولي إلى 1,000,462 جنيه مصري والهدف إلى 1,250,000 جنيه مصري؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onResetBaseline()
                        showResetDialog = false
                    }
                ) {
                    Text("نعم، استعادة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showChangePinDialog) {
        var oldPinStr by remember { mutableStateOf("") }
        var newPinStr by remember { mutableStateOf("") }
        var confirmPinStr by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = {
                showChangePinDialog = false
                pendingEnableLock = false
            },
            title = { Text("تعيين رمز مرور جديد (PIN)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "الرمز يجب أن يتكون من 4 أرقام. سيُستخدم هذا الرمز لفتح الخزانة وتأكيد عمليات البيع والتسييل.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    if (hasPin) {
                        OutlinedTextField(
                            value = oldPinStr,
                            onValueChange = { if (it.length <= 4) oldPinStr = it },
                            label = { Text("رمز المرور الحالي") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("old_pin_input")
                        )
                    }

                    OutlinedTextField(
                        value = newPinStr,
                        onValueChange = { if (it.length <= 4) newPinStr = it },
                        label = { Text("رمز المرور الجديد (4 أرقام)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("new_pin_input")
                    )

                    OutlinedTextField(
                        value = confirmPinStr,
                        onValueChange = { if (it.length <= 4) confirmPinStr = it },
                        label = { Text("تأكيد رمز المرور") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = pinError != null,
                        supportingText = pinError?.let { { Text(it, color = LossRed) } },
                        modifier = Modifier.fillMaxWidth().testTag("confirm_pin_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!PinHasher.isValidFormat(newPinStr)) {
                            pinError = "يجب أن يتكون الرمز من 4 أرقام عددية"
                            return@Button
                        }
                        if (PinHasher.isWeak(newPinStr)) {
                            pinError = "الرمز سهل التخمين (مثل 1234 أو 0000). اختر رمزاً آخر"
                            return@Button
                        }
                        if (newPinStr != confirmPinStr) {
                            pinError = "الرمزان غير متطابقين، يرجى إعادة المحاولة"
                            return@Button
                        }
                        pinScope.launch {
                            if (hasPin) {
                                val check = verifyPin(oldPinStr)
                                if (check != PinResult.Success) {
                                    pinError = check.toUserMessage()
                                    oldPinStr = ""
                                    return@launch
                                }
                            }
                            val enableLock = appLockEnabled || pendingEnableLock
                            appLockEnabled = enableLock
                            onUpdateSecuritySettings(enableLock, requireAuthOnSale, biometricEnabled, newPinStr)
                            pendingEnableLock = false
                            showChangePinDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = Color(0xFF1E1700)),
                    modifier = Modifier.testTag("save_pin_button")
                ) {
                    Text("حفظ الرمز")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showChangePinDialog = false
                    pendingEnableLock = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
