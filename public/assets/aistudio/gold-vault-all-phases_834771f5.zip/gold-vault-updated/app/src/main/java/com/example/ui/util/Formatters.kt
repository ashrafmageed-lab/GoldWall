package com.example.ui.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Formatters {

    private val cairoTimeZone = TimeZone.getTimeZone("Africa/Cairo")

    private val symbols = DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = ','
        decimalSeparator = '.'
    }

    private val currencyFormat = DecimalFormat("#,##0.00", symbols)
    private val weightFormat = DecimalFormat("#,##0.0000", symbols)
    private val shortWeightFormat = DecimalFormat("#,##0.00", symbols)
    private val percentFormat = DecimalFormat("#,##0.00", symbols)

    fun formatCurrency(amount: Double): String {
        return "${currencyFormat.format(amount)} ج.م"
    }

    fun formatWeight(grams: Double): String {
        return "${weightFormat.format(grams)} جم"
    }

    fun formatWeightShort(grams: Double): String {
        return "${shortWeightFormat.format(grams)} جم"
    }

    fun formatPercent(pct: Double): String {
        val sign = if (pct > 0) "+" else ""
        return "$sign${percentFormat.format(pct)}%"
    }

    fun formatDateTime(timestamp: Long): String {
        if (timestamp <= 0) return "غير محدد"
        val sdf = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar", "EG"))
        sdf.timeZone = cairoTimeZone
        return sdf.format(Date(timestamp))
    }

    fun formatDateShort(timestamp: Long): String {
        if (timestamp <= 0) return "غير محدد"
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale("ar", "EG"))
        sdf.timeZone = cairoTimeZone
        return sdf.format(Date(timestamp))
    }
}
