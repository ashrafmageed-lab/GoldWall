package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.GoldBar
import kotlinx.coroutines.flow.Flow

@Dao
interface GoldBarDao {

    @Query("SELECT * FROM gold_bars ORDER BY weight DESC, id ASC")
    fun getAllGoldBars(): Flow<List<GoldBar>>

    @Query("SELECT * FROM gold_bars WHERE id = :id LIMIT 1")
    suspend fun getGoldBarById(id: Long): GoldBar?

    @Query("SELECT COUNT(*) FROM gold_bars")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goldBar: GoldBar): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(goldBars: List<GoldBar>): List<Long>

    @Update
    suspend fun update(goldBar: GoldBar)

    @Delete
    suspend fun delete(goldBar: GoldBar)

    @Query("DELETE FROM gold_bars WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM gold_bars")
    suspend fun clearAll()

    @Query("SELECT SUM(weight) FROM gold_bars")
    fun getTotalWeight(): Flow<Double?>

    @Query("SELECT SUM(cost) FROM gold_bars")
    fun getTotalCost(): Flow<Double?>
}
