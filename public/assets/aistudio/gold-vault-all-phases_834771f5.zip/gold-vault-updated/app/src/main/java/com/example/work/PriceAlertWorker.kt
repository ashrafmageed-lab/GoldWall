package com.example.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.data.local.AppDatabase
import com.example.data.local.PriceCache
import com.example.data.remote.GoldPriceProvider
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Background gold-price alert: runs hourly (when online), compares the 21k jeweler buy price with
 * the last price the user was notified about, and posts a real system notification when the move
 * reaches the threshold chosen in Settings. Works while the app is closed.
 */
class PriceAlertWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.getDatabase(applicationContext)
        val settings = db.settingsDao().getSettingsSnapshot() ?: return Result.success()
        if (!settings.priceAlertsEnabled || settings.priceAlertThresholdEgp <= 0.0) return Result.success()

        val fetched = GoldPriceProvider().fetchGoldPrices()
        val state = fetched.getOrNull() ?: return if (runAttemptCount < 2) Result.retry() else Result.success()
        PriceCache(applicationContext).save(state)

        val price = state.gram21BuyEgp
        val baseline = settings.lastNotifiedPrice21Egp
        if (baseline <= 0.0) {
            // First run: just remember today's price as the reference. No notification yet.
            db.settingsDao().insertOrUpdate(settings.copy(lastNotifiedPrice21Egp = price))
            return Result.success()
        }

        val diff = price - baseline
        if (Math.abs(diff) >= settings.priceAlertThresholdEgp) {
            notifyMove(diff, price)
            db.settingsDao().insertOrUpdate(settings.copy(lastNotifiedPrice21Egp = price))
        }
        return Result.success()
    }

    private fun notifyMove(diff: Double, price: Double) {
        val ctx = applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "تنبيهات سعر الذهب", NotificationManager.IMPORTANCE_DEFAULT)
            ctx.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val direction = if (diff > 0) "ارتفاع" else "انخفاض"
        val notification = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("حركة سعر الذهب: $direction عيار 21")
            .setContentText(
                String.format(Locale.US, "%.1f ج.م — السعر الآن %.1f ج.م/جم", Math.abs(diff), price)
            )
            .setContentIntent(open)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            // Permission revoked between the check and the call.
        }
    }

    companion object {
        private const val CHANNEL_ID = "gold_price_alerts"
        private const val NOTIFICATION_ID = 4201
        private const val UNIQUE_NAME = "gold_price_alerts"

        fun setEnabled(context: Context, enabled: Boolean) {
            val wm = WorkManager.getInstance(context.applicationContext)
            if (!enabled) {
                wm.cancelUniqueWork(UNIQUE_NAME)
                return
            }
            val request = PeriodicWorkRequestBuilder<PriceAlertWorker>(1, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
