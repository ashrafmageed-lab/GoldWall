package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.GoldBar
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GoldBarUiState(
    val bars: List<GoldBar> = emptyList(),
    val totalWeightGrams: Double = 0.0,
    val totalCostEgp: Double = 0.0,
    val isInitialized: Boolean = false,
    val message: String? = null
)

/**
 * ViewModel specifically designed to store and manage the initial gold bar inventory:
 * (0.5g, 1g, 10g, 50g, 1oz) with fields for weight, karat, cost, and status.
 */
class GoldBarViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val goldBarDao = database.goldBarDao()

    val goldBars: StateFlow<List<GoldBar>> = goldBarDao.getAllGoldBars()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppDatabase.getInitialGoldBarList()
        )

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        // Automatically ensure initial 5 gold bars exist in inventory
        viewModelScope.launch {
            if (goldBarDao.getCount() == 0) {
                goldBarDao.insertAll(AppDatabase.getInitialGoldBarList())
            }
        }
    }

    /**
     * Add a gold bar with weight, karat, cost, and status
     */
    fun addGoldBar(
        weight: Double,
        karat: Int = 24,
        cost: Double? = null,
        status: String = "مغلفة وسليمة",
        title: String = "سبيكة BTC",
        notes: String = ""
    ) {
        viewModelScope.launch {
            val newBar = GoldBar(
                title = title,
                weight = weight,
                karat = karat,
                cost = cost,
                status = status,
                brand = "BTC",
                notes = notes
            )
            goldBarDao.insert(newBar)
            _statusMessage.value = "تمت إضافة سبيكة بوزن $weight جم بنجاح"
        }
    }

    /**
     * Update an existing gold bar's weight, karat, cost, status
     */
    fun updateGoldBar(
        id: Long,
        weight: Double,
        karat: Int,
        cost: Double?,
        status: String,
        title: String? = null,
        notes: String? = null
    ) {
        viewModelScope.launch {
            val existing = goldBarDao.getGoldBarById(id)
            if (existing != null) {
                goldBarDao.update(
                    existing.copy(
                        title = title ?: existing.title,
                        weight = weight,
                        karat = karat,
                        cost = cost,
                        status = status,
                        notes = notes ?: existing.notes
                    )
                )
                _statusMessage.value = "تم تحديث السبيكة بنجاح"
            }
        }
    }

    /**
     * Delete a gold bar
     */
    fun deleteGoldBar(goldBar: GoldBar) {
        viewModelScope.launch {
            goldBarDao.delete(goldBar)
            _statusMessage.value = "تم حذف السبيكة من المخزون"
        }
    }

    /**
     * Delete by ID
     */
    fun deleteGoldBarById(id: Long) {
        viewModelScope.launch {
            goldBarDao.deleteById(id)
            _statusMessage.value = "تم حذف السبيكة"
        }
    }

    /**
     * Reset inventory to the original initial 5 BTC bars (0.5g, 1g, 10g, 50g, 1oz)
     */
    fun resetToInitialInventory() {
        viewModelScope.launch {
            goldBarDao.clearAll()
            goldBarDao.insertAll(AppDatabase.getInitialGoldBarList())
            _statusMessage.value = "تمت استعادة مخزون السبائك الابتدائي (5 سبائك)"
        }
    }

    fun clearMessage() {
        _statusMessage.value = null
    }
}
